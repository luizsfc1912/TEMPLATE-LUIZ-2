from flask import Flask, jsonify
from flask_cors import CORS
import requests

app = Flask(__name__)
CORS(app)

# Substitua pela sua chave da OpenWeatherMap
API_KEY = 'e8f5eb4cd88eb044371077da10cbafa4'

# Mapeamento dos locais para cidades
LOCAIS = {
    "Castelão": "Ceará,BR",
    "Vila Belmiro": "Santos,BR",
    "Campos Maia": "São Paulo,BR",
    "Beira Rio": "Porto Alegre,BR",
}

def get_temperatura(cidade):
    url = f'https://api.openweathermap.org/data/2.5/weather?q={cidade}&appid={API_KEY}&units=metric&lang=pt_br'
    try:
        resp = requests.get(url)
        data = resp.json()
        return round(data['main']['temp'])
    except Exception:
        return None

@app.route('/proximos_jogos')
def proximos_jogos():
    jogos = [
        {
            "data": "12/06/2025",
            "hora": "19:30",
            "adversario": "Fortaleza",
            "local": "Castelão"
        },
        {
            "data": "13/07/2025",
            "hora": "16:00",
            "adversario": "Palmeiras",
            "local": "Vila Belmiro"
        },
        {
            "data": "16/07/2025",
            "hora": "21:00",
            "adversario": "Flamengo",
            "local": "Vila Belmiro"
        },
        {
            "data": "20/07/2025",
            "hora": "18:30",
            "adversario": "Mirassol",
            "local": "Campos Maia"
        },
        {
            "data": "23/07/2025",
            "hora": "19:30",
            "adversario": "Internacional",
            "local": "Beira Rio"
        }
    ]
    # Adiciona temperatura real
    for jogo in jogos:
        cidade = LOCAIS.get(jogo["local"])
        if cidade:
            temp = get_temperatura(cidade)
            jogo["temperatura"] = temp
        else:
            jogo["temperatura"] = None
    return jsonify(jogos)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)